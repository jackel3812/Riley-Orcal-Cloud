"""
Riley Features Server
Main server application that handles feature requests
"""
import asyncio
import json
import logging
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from api_handler import FeatureAPIHandler

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(title="Riley Features Server")
api_handler = FeatureAPIHandler()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://*.oraclecloud.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}

@app.post("/api/{feature}/{operation}")
async def handle_feature_request(feature: str, operation: str, data: dict):
    """Handle feature requests"""
    try:
        result = await api_handler.handle_request(feature, operation, data)
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/features")
async def list_features():
    """List available features"""
    return {
        "features": [
            {
                "name": feature,
                "enabled": config.get("enabled", False),
                "endpoint": config.get("endpoint", "")
            }
            for feature, config in api_handler.feature_config["features"].items()
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
